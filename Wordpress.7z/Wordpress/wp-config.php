<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'mysite3' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', 'admin' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'dW0NT+/;r?;90}r~zjeUM0c[: j)`@ItM5^=G{+EvEN.fU~?CwzNs|NLY/6!&E}A' );
define( 'SECURE_AUTH_KEY',  '#14+}Ex7(puM.3`msS*R@P]Lv}/n4W6!sGHDisl[+yL92bmxScT|Hk=I/$n1E[B|' );
define( 'LOGGED_IN_KEY',    '*M3cdgd5p@bN>m >e*f-,D`bK7(Q1<FKg3>r6^0%]c%Dg?%X%y~hL@g+AN6a!6@&' );
define( 'NONCE_KEY',        ',h!86dggpmUrADA|-tpUziQJEa-/p,&d4%.h)hvnbnT,v[d[Q)cpZXM>(Z8[JzeT' );
define( 'AUTH_SALT',        '>`.m$Fs8H8a>U8gd1UsNhiNJeUDuE!s,zMu,kwiC@55!}6ds{L!J|AGYS0`3)]zP' );
define( 'SECURE_AUTH_SALT', '%%|gwb]m3n)*qe<[QUuVIQQO:1MI$?u?h$JGpWE%S4amCk}c{0VpuB#:h&VTo*;v' );
define( 'LOGGED_IN_SALT',   'U#KV;QCJ&D48DxJjl=rDQ$jHpB]gWd,JBr_pcd^bK7BLk~Fz=0z<=.I)zD@B_n::' );
define( 'NONCE_SALT',       '|^4mlNMxn~*C:=zu`ny3*VyKy@1(J-7xz$S+v.y:s%ybN=?/vHpQngN{]=|b;R|>' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
